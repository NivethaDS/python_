from tkinter import *

root = Tk()
def dosome():
    print("Hey..! You are going to rock the world")
button1 = Button(root, text="click here",command=dosome)
button1.pack()

root.mainloop()