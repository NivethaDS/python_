from tkinter import *

root = Tk()

label1 = Label(root, text="Hello world")

label1.pack()

root.mainloop()
