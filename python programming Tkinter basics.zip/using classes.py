from tkinter import *

class mybuttons:

    def __init__(self,rootone):
        frame = Frame(rootone)
        frame.pack()

        self.printbutton = Button(frame, text="Click here", command=self.printmessage)
        self.printbutton.pack()

        self.exitbutton = Button(frame, text="Exit", command=frame.quit())#directly quit
        self.exitbutton.pack()
    def printmessage(self):
        print("Button clicked")


root = Tk()
b = mybuttons(root)

root.mainloop()